#include <stdio.h>

int main()
{
	int a,b;

	b = -8;

	if( (a=b) )
		puts("Value assigned");
	else
		puts("Value is zero");

	return(0);
}
