#include <stdio.h>

int main()
{
	unsigned char a = 0;

	while(a < 200)
	{
		printf("%3d\n",a);
		a++;
	}

	return(0);
}

