#include <stdio.h>

int main()
{
	char a = 0;

	while(a < 200)
	{
		printf("%3d\n",a);
		a++;
	}

	return(0);
}

