#include <stdio.h>

int main()
{
	int array[3] = { 100, 200, 300 };
	int e = 53;

	printf("Element %d is %d\n",e,array[e]);

	return(0);
}
