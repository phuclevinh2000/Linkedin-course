#include <stdio.h>

int main()
{
	int array[3] = { 100, 200, 300 };

	printf("The 4th element is %d\n",array[3]);

	return(0);
}
