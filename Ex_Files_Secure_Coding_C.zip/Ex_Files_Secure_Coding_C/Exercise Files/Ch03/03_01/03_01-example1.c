#include <stdio.h>

int main()
{
	int age;

	printf("Your age: ");
	scanf("%d",&age);
	printf("You will be %d years old next year\n",age+1);

	return(0);
}
