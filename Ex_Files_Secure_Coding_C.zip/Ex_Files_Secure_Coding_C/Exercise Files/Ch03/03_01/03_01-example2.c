#include <stdio.h>

int main()
{
	float gas;

	printf("The price of gas: ");
	scanf("%f",&gas);
	printf("Wow! %.2f for gas?\n",gas);

	return(0);
}
