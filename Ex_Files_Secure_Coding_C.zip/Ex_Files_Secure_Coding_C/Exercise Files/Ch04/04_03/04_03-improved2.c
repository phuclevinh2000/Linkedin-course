#include <stdio.h>

int main()
{
	char prompt[] = "Press any key: ";

	printf("%s",prompt);
	getchar();

	return(0);
}
