#include <stdio.h>

int main()
{
	const char *prompt = "Press any key: ";

	printf("%s",prompt);
	getchar();

	return(0);
}
