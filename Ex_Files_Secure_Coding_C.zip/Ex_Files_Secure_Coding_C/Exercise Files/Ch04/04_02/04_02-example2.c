#include <stdio.h>

int main()
{
	char s[3] = { 'a', 'b', 'c' };

	printf("This isn't a string: '%s'\n",s);

	return(0);
}
