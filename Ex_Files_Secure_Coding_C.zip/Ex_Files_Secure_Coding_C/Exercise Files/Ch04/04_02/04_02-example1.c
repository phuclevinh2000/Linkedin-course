#include <stdio.h>

int main()
{
	char string[3] = "abc";

	printf("Here's your string: '%s'\n",string);

	return(0);
}
