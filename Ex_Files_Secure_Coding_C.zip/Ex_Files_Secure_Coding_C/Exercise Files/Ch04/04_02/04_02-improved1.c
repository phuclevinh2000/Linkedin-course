#include <stdio.h>

int main()
{
	char string[] = "abc";

	printf("Here's your string: '%s'\n",string);

	return(0);
}
