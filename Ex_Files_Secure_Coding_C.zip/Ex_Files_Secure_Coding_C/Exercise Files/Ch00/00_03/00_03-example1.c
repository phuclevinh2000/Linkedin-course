#include <stdio.h>

int main()
{
	puts("This code does nothing so it's very secure.");

	return(0);
}
